package com.pack.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pack.dao.PizzaOrderDAO;
import com.pack.exception.OrderNotFoundException;
import com.pack.model.Customer;
import com.pack.model.PizzaOrder;


	 
	public class PizzaOrderService implements IPizzaOrderService {
	 
		@Autowired
		private PizzaOrderDAO pizzaDao;

		@Override
		public int loginCheck(String username, String password) {
			// TODO Auto-generated method stub
			int k=pizzaDao.loginCheck(username,password);  
		return k;
		}

		@Override
		public int placeOrder(Customer customer,PizzaOrder  pizza,double top){
			int k=pizzaDao.placeOrder(customer,pizza,top);
			return k;
		}
		
		public PizzaOrder getOrderById(int id) throws OrderNotFoundException
		{
			
			PizzaOrder pizza= pizzaDao.getOrderById(id);
			return pizza;
		}
		
		 public int updateOrder(PizzaOrder pizza,double pTopping)  
		 
		  {
			int k= pizzaDao.updateOrder(pizza ,pTopping);  
			return k;
		}
		 public Customer getCustomerById(int custid)
			{
				Customer customer= pizzaDao.getCustomerById(custid);
				return customer;
			}
		 public int deleteOrder(PizzaOrder pizza){
			 
			 int k= pizzaDao.deleteOrder(pizza);  
				return k; 
		 }
public Object[] getData(int id,PizzaOrder pizza,Customer customer) throws OrderNotFoundException{
			 
			 Object[] row=pizzaDao.getData(id, pizza, customer);
			 return row;
		 }
		 
	 
		@Override
		public int modifyOrder(PizzaOrder order) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int displayOrder(PizzaOrder order) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int logout() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int login() {
			// TODO Auto-generated method stub
			return 0;
		}


	


		
			 
		 
			 
	}

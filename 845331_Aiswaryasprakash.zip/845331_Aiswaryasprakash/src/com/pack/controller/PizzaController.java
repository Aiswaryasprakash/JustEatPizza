package com.pack.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Login;
import com.pack.exception.OrderNotFoundException;
import com.pack.model.Customer;
import com.pack.model.PizzaOrder;
import com.pack.service.PizzaOrderService;
 
@Controller
public class PizzaController {
 
	@Autowired
	private PizzaOrderService pizzaService;

	@RequestMapping("/loginpage")  
	    public ModelAndView displayLogin()
	    {  
	        return new ModelAndView("loginpage","login", new Login());
	    }
		
	
	
	
		  @RequestMapping(value="/loginsuccess", method = RequestMethod.GET)
		  public ModelAndView toLogin(String username,String password) { 
			 int k=pizzaService.loginCheck(username, password);
			 if(k==1)
			 {
			 return new ModelAndView("homepage"); 
			 }
			 else return new ModelAndView("loginfailure"); 
		  }
		  
		  @RequestMapping("/placeorder")
			public ModelAndView toOrder() {
				return new ModelAndView("orderingpage", "Customer",new Customer());
			}
			
			@RequestMapping(value="/pickorder", method=RequestMethod.GET)

			public ModelAndView getOrder(Customer customer,@RequestParam("toppings")double top, Model m,PizzaOrder pizza) 
			{ 

				int k=pizzaService.placeOrder(customer,pizza,top);
				m.addAttribute("orderid", k);
				return new ModelAndView("ordersuccessful");
			}
			
			@RequestMapping("/ordermodification")  
			public ModelAndView toModify()
			{  
				return new ModelAndView("ordermodification","customer", new Customer());
			}

			@RequestMapping(value = "/modification")   
			public ModelAndView showupdateUser(@RequestParam("id") int id,PizzaOrder pizza,Model m)  throws OrderNotFoundException{
				pizza=pizzaService.getOrderById(id);
				try {
					if(pizza==null) 
						throw new OrderNotFoundException();	

				}catch(OrderNotFoundException e) {
					m.addAttribute("ex",e);
					return  new ModelAndView("errorpage"); 
				}
				m.addAttribute("modifyBean",pizza);
				return new ModelAndView("showmodification"); 
			} 			

			@RequestMapping("/showModification")
			public String update(PizzaOrder pizza,@RequestParam("toppings")double top,Model m)
			{

				int k= pizzaService.updateOrder(pizza,top);
				m.addAttribute("orderid", k);
				return "ordersuccessful";

			}

			@RequestMapping("/deleteorder")

			public ModelAndView toDelete()
			{

				return new ModelAndView("deleteorder");
			}




			
			
			 @RequestMapping(value = "/showDeleteOrder")
			  public ModelAndView showdeleteOrder(@RequestParam("id") int id,PizzaOrder pizza,Model m) throws OrderNotFoundException{
			  pizza=pizzaService.getOrderById(id);
				try { 
					if(pizza==null)
						throw new OrderNotFoundException();
					
				}catch (OrderNotFoundException e) {
					m.addAttribute("ex",e);
					return new ModelAndView("errorpage");
				}
			  
			  m.addAttribute("deleteBean",pizza);
			  return new ModelAndView("showDelete"); 
			  
			  }

				@RequestMapping("/delete")

				public String delete(PizzaOrder pizza,Model m)
				{
int k=pizzaService.deleteOrder(pizza);
					return "deletesuccessful";
				}	
		
				@RequestMapping("/displayorder")
				public ModelAndView toDisplay()
				{
					return new ModelAndView("displayOrder");
				}
				@RequestMapping("/showDisplayOrder") 
				public ModelAndView showdisplayOrder(@RequestParam("id") int id,PizzaOrder pizza,Model m,Customer customer) throws OrderNotFoundException
				{
					
					
					
					pizza=pizzaService.getOrderById(id);
					
					try {
						if(pizza==null) 
							throw new OrderNotFoundException();	

					}catch(OrderNotFoundException e) {
						m.addAttribute("ex",e);
						return  new ModelAndView("errorpage"); 
					}
					Object[] row=pizzaService.getData(id,pizza,customer);		
					m.addAttribute("row",row);
					return new ModelAndView("showOrder");

				}

				@RequestMapping("/homee")  
				public String displayHome()
				{  
					return "homepage";
				}

			
}
	


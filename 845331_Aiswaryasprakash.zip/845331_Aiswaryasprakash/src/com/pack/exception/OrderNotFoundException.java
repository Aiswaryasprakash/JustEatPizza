package com.pack.exception;

public class OrderNotFoundException extends Exception {
public String toString() {
	return "Sorry !! Order does not exist";
}
}

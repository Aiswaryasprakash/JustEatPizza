package com.pack.model;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.Proxy;
@Entity
@Table(name="pizzaorder")
@Proxy(lazy=false)
public class PizzaOrder {
	@Id
	@GeneratedValue


	/*@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "custid",unique=true)
	private Customer customerOrder;*/
	
	@Column(name="orderid")	
	int orderid;
	@Column(name="custid")	
	int id;
	@Column(name="totalprice")
	double totalprice;
	@Column(name="orderdate")
	String orderdate;
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(double totalprice) {
		this.totalprice = totalprice;
	}
	public String getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(String orderdate) {
		this.orderdate = orderdate;
	}

	
}


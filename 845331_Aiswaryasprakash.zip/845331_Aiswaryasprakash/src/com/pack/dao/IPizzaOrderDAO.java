package com.pack.dao;
import java.util.List;

import com.pack.exception.OrderNotFoundException;
import com.pack.model.Customer;
import com.pack.model.PizzaOrder;
public interface IPizzaOrderDAO {
	

 	public int login();
 	public int placeOrder(Customer customer,PizzaOrder  pizza,double pTopping);
 	public PizzaOrder getOrderById(int id)throws OrderNotFoundException;
 	public Object[] getData(int id,PizzaOrder pizza,Customer customer) throws OrderNotFoundException;
 	public Customer getCustomerById(int custid);
 	 public int updateOrder(PizzaOrder pizza,double pTopping);
 	public int deleteOrder(PizzaOrder pizza) ;
	
	 public int modifyOrder(PizzaOrder order); 
	 public int displayOrder(PizzaOrder order);
	 public int logout();
	public int loginCheck(String username, String password);

	}

		
